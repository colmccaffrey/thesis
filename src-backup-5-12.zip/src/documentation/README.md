## The Sum of Us

## What can crowdfunding tell us about the gaps in the American healthcare system?

[Thesis Project Url](https://colmccaffrey.github.io/thesis)

Colleen McCaffrey 2019
