
//set function triggers on scroll position
//set each section to a set window height to get easier trigger values from divs and move
// window.addEventListener("scroll", function () {
//     var offsets = document.getElementById('title').getBoundingClientRect();
//     var top = offsets.top;
//     // console.log(top);
//     if (top < -10) {
//         update(nodeRadiusCluster);
//     }
// });